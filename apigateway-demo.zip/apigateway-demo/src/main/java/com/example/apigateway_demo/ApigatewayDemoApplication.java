package com.example.apigateway_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApigatewayDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApigatewayDemoApplication.class, args);
	}

}
